
describe('environmental variables', () => {

    expect(process.env.FB_APP_ID).toEqual(296951654636901);
});

